@echo off
setlocal
cd /d "%~dp0"
set "APP_EXE="
for %%F in ("%~dp0dist\*.exe") do if exist "%%~fF" set "APP_EXE=%%~fF"
if not defined APP_EXE (
  echo The desktop EXE has not been built yet.
  echo Run BUILD-AND-RUN.bat first.
  pause
  exit /b 1
)
start "" "%APP_EXE%"
