@echo off
setlocal
cd /d "%~dp0"
title Screen Recorder Pro 5 - Windows Desktop Build

echo ================================================
echo   Screen Recorder Pro 5 - Desktop Application
echo ================================================
echo.

where node >nul 2>nul
if errorlevel 1 goto missing_node
where npm >nul 2>nul
if errorlevel 1 goto missing_npm

echo [1/3] Installing desktop application packages...
call npm install --no-audit --no-fund
if errorlevel 1 goto install_failed

echo.
echo [2/3] Building the standalone Windows EXE...
call npm run dist:win
if errorlevel 1 goto build_failed

echo.
echo [3/3] Opening Screen Recorder Pro 5...
set "APP_EXE="
for %%F in ("%~dp0dist\*.exe") do if exist "%%~fF" set "APP_EXE=%%~fF"
if not defined APP_EXE goto exe_missing
start "" "%APP_EXE%"
echo.
echo The desktop application has been launched.
echo The EXE is in the dist folder.
timeout /t 5 >nul
exit /b 0

:missing_node
echo ERROR: Node.js is not installed or not in PATH.
echo Install Node.js LTS, then run this file again.
goto failed

:missing_npm
echo ERROR: npm is not installed or not in PATH.
goto failed

:install_failed
echo ERROR: Package installation failed.
echo Check your internet connection and run this file again.
goto failed

:build_failed
echo ERROR: Windows EXE build failed.
echo Read the error messages above.
goto failed

:exe_missing
echo ERROR: Build finished but no EXE was found in the dist folder.
goto failed

:failed
echo.
pause
exit /b 1
